package com.example.miaplicacion;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ClienteNuevo extends AppCompatActivity {

    private EditText txtCodigoInterno;
    private EditText txtNombreApellido;
    private EditText txtCedula;
    private EditText txtTelefono;
    private EditText txtDireccion;
    private Button btnGuardarCliente;
    private Button btnCancelarCliente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cliente_nuevo);

        setTitle("REGISTRAR NUEVO CLIENTE");

        txtCodigoInterno = (EditText) findViewById(R.id.txtCodigoCliente);
        txtNombreApellido = (EditText) findViewById(R.id.txtNombreApellido);
        txtCedula = (EditText) findViewById(R.id.txtCedula);
        txtTelefono = (EditText) findViewById(R.id.txtTelefono);
        txtDireccion = (EditText) findViewById(R.id.txtDireccion);
    }
    public void RegistrarCliente(View view){
        AdminSQLiteOpenHelper admin =new AdminSQLiteOpenHelper(this, "mga", null, 1);
        SQLiteDatabase BaseDeDatos = admin.getWritableDatabase();

        String codigo = txtCodigoInterno.getText().toString();
        String nombre_apellido = txtNombreApellido.getText().toString();
        String cedula = txtCedula.getText().toString();
        String telefono = txtTelefono.getText().toString();
        String direccion = txtDireccion.getText().toString();

        if (!codigo.isEmpty() && !nombre_apellido.isEmpty()){
            ContentValues registro =new ContentValues();

            registro.put("idCliente", codigo);
            registro.put("nombre_apellido", nombre_apellido);
            registro.put("cedula", cedula);
            registro.put("telefono", telefono);
            registro.put("direccion", direccion);

            BaseDeDatos.insert("cliente", null, registro);
            BaseDeDatos.close();

            txtCodigoInterno.setText("");
            txtNombreApellido.setText("");
            txtCedula.setText("");
            txtTelefono.setText("");
            txtDireccion.setText("");

            Toast.makeText(this, "Registro de cliente exitoso!", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, ClienteLista.class);
            startActivity(intent);
        } else{
            Toast.makeText(this, "Debes llenar todos los campos", Toast.LENGTH_LONG).show();
        }
    }
    public void CancelarCliente(View view){
        txtCodigoInterno.setText("");
        txtNombreApellido.setText("");
        txtCedula.setText("");
        txtTelefono.setText("");
        txtDireccion.setText("");
        Toast.makeText(this, "Campos del mantenimiento vaciados!", Toast.LENGTH_LONG).show();
    }

}