package com.example.miaplicacion;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;


public class ClienteLista extends AppCompatActivity {

    private Context mCont=this;
    private FloatingActionButton btnFlotanteNuevoCliente;
    private ListView lv;
    ArrayList<String> listaClientes;
    ArrayAdapter adaptadorClientes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cliente_lista);

        setTitle("LISTA DE CLIENTES");

        cargarTabla();

        //codigo para el boton flotante
        btnFlotanteNuevoCliente = (FloatingActionButton) findViewById(R.id.btnFlotanteNuevoCliente);

                btnFlotanteNuevoCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mCont, ClienteNuevo.class);
                startActivity(intent);
            }

        });

    }
    public void cargarTabla(){
        lv = (ListView) findViewById(R.id.listaClientes);
        AdminSQLiteOpenHelper admin =new AdminSQLiteOpenHelper(this, "mga", null, 1);
        listaClientes = admin.llenar_lv_clientes();
        adaptadorClientes = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listaClientes);
        lv.setAdapter(adaptadorClientes);
    }
}