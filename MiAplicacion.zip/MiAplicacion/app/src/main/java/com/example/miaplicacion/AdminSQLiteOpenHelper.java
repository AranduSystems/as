package com.example.miaplicacion;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

import java.util.ArrayList;

public class AdminSQLiteOpenHelper extends SQLiteOpenHelper {
    public AdminSQLiteOpenHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);

    }
    @Override
    public void onCreate(SQLiteDatabase BaseDeDatos) {
        BaseDeDatos.execSQL("create table cliente(idcliente int primary key, nombre_apellido text, cedula text, telefono number, direccion text)");
        BaseDeDatos.execSQL("create table matricula(idmatricula int primary key, descripcion text, monto float)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public ArrayList llenar_lv_clientes(){
        ArrayList<String> lista = new ArrayList<>();
        SQLiteDatabase database = this.getReadableDatabase();
        String q = "SELECT * FROM cliente;";
        Cursor registros = database.rawQuery(q, null);

        if (registros.moveToFirst()){
            do {
                lista.add(registros.getString(0)+"-"+registros.getString(1));
            } while (registros.moveToNext());
        }

        return lista;
    }
}
